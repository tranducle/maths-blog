---
name: maths-blog-publisher
description: Publish posts to the "Proof & Practice" maths teaching blog at maths-blog.vercel.app — create/update/delete/list posts via the Agent API, with full support for KaTeX math, TikZ diagrams (LaTeX-quality SVG), and Markdown formatting. Use whenever the user wants to write, draft, publish, or manage a blog post about maths (algebra, geometry, calculus, proofs, teaching), or mentions "blog", "đăng bài", "viết bài", "Proof & Practice", or any maths diagram/equation to publish.
---

# Maths Blog Publisher

Publish posts to the **Proof & Practice** maths teaching blog. This skill knows
how to format articles (Markdown + KaTeX + TikZ), call the blog's Agent API, and
handle the one critical gotcha — backslash escaping — that breaks most diagrams.

## The blog

- **Live site:** https://maths-blog.vercel.app
- **Admin login:** https://maths-blog.vercel.app/admin/login (`troisrivers`)
- **Tech:** Next.js + KaTeX (math) + TikZ via real LaTeX compile + Supabase Postgres

## The Agent API (how to publish)

All requests need a bearer token. **It's already configured** — read it from
`~/.agents/skills/maths-blog-publisher/scripts/.api-key` (or the `MATHS_BLOG_API_KEY`
env var). Never ask the user for it.

```
Authorization: Bearer <API_KEY>
```

| Method | Endpoint | Purpose |
|--------|----------|---------|
| `GET`  | `/api/agent/posts?status=all&q=&tag=&limit=` | List/search posts |
| `POST` | `/api/agent/posts` | Create (draft or published) |
| `PUT`  | `/api/agent/posts/{id}` | Update (partial) |
| `DELETE` | `/api/agent/posts/{id}` | Delete |

Use the helper script for create/update (it handles escaping correctly):
`node ~/.agents/skills/maths-blog-publisher/scripts/publish.mjs --help`

## Article format = Markdown

`bodyMarkdown` is plain Markdown with three superpowers:

1. **KaTeX math** — `$...$` inline, `$$...$$` display. Backslashes: `\frac`, `\sum`, `\int`.
2. **TikZ diagrams** — a fenced code block tagged `tikz` (see "Drawing diagrams" below).
3. **Custom blocks** — `:::pullquote ... :::`, `:::figure ... :::figcaption ... :::`.

Standard Markdown also works: `# headings`, `- lists`, `[links](url)`,
`![images](url)`, `` `inline code` ``, ` ```js code blocks ``` `.

### Body field reference (for POST/PUT)

| Field | Type | Required | Default | Notes |
|-------|------|----------|---------|-------|
| `title` | string | **yes** | — | |
| `bodyMarkdown` | string | no | `""` | The article (see format above). |
| `status` | string | no | `"draft"` | `"draft"` or `"published"`. |
| `slug` | string | no | derived from title | URL slug; must be unique. |
| `deck` | string | no | `""` | One-line summary shown on the card. |
| `category` | string | no | `"General"` | e.g. "Algebra", "Geometry". |
| `tags` | string[] | no | `[]` | e.g. `["calculus","proofs"]`. |
| `author` | string | no | `"Anonymous"` | |

**Workflow recommendation:** create as `draft` first, verify it renders, then
`PUT` with `status: "published"`. Drafts are NOT publicly reachable by slug.

## Drawing diagrams (TikZ) — READ THIS CAREFULLY

Diagrams compile with **real LaTeX** (xelatex → SVG) at save time, so they look
exactly like Overleaf. The render service is already wired up.

### The #1 rule: backslash escaping

This is the single most common bug. In the **TikZ source** (the string you write
into `bodyMarkdown`), use **single backslashes**: `\draw`, `\node`, `\fill`,
`\begin{tikzpicture}`.

When that string is sent over JSON, each `\` becomes `\\` **automatically** by
the JSON encoder. **Do NOT manually double the backslashes.** If you write
`\\draw` in the source, it becomes `\\\\draw` over the wire, which is wrong.

| What you want to draw | In the TikZ source (bodyMarkdown) | Sent over JSON (automatic) |
|-----------------------|-----------------------------------|----------------------------|
| draw a line | `\draw` | `\\draw` |
| place a label | `\node` | `\\node` |
| begin picture | `\begin{tikzpicture}` | `\\begin{tikzpicture}` |

**In Python:** use a raw string `r"\draw ..."` and pass it via `json=...` (not
`data=`). **In Node:** use `String.raw\`\draw ...\`` and `JSON.stringify`. The
helper script does this for you.

**Symptom of wrong escaping:** the diagram renders blank, or shows 1-2 stray
characters instead of the picture. The page's browser console shows
`Missing svg element`.

### Structure of a diagram

Only send the **body** — the `\begin{tikzpicture}...\end{tikzpicture}` part.
Do NOT send `\documentclass`, `\usepackage`, or `\begin{document}`; the render
service adds those.

````markdown
Some intro text, then the diagram:

```tikz
\begin{tikzpicture}[thick]
  \fill[blue!15] (0,0) -- (4,0) -- (0,3) -- cycle;
  \draw (0,0) -- (4,0) -- (0,3) -- cycle;
  \node[below] at (2,0) {$b$};
\end{tikzpicture}
```
````

### Pre-loaded TikZ libraries

Available without `\usetikzlibrary` (already in the template):
`arrows.meta`, `calc`, `decorations.pathreplacing`, `positioning`, `shapes.geometric`.

If you need another (e.g. `angles`, `plot`, `intersections`, `pgfplots`), tell the
user it's not available — only the above 5 work.

### Unicode works

Vietnamese, accented characters, CJK all render (xelatex). Example:
`\node {Đầu vào $x$};` compiles fine.

### Hard rules

- Every TikZ command ends with `;` (`\draw (0,0)--(1,0);`).
- Labels with math use `$...$`: `\node at (1,0) {$\theta$};`.
- Colors: `blue!20` (20% blue), named colors, hex via `\definecolor`.
- Compile takes 3-8 seconds per diagram; saving a post with many diagrams is slow.

### Worked examples (verified)

See `references/tikz-examples.md` for 5 copy-paste diagrams (right triangle,
unit circle, parabola, Vietnamese flowchart, labeled triangle). Always start
from one of those rather than inventing from scratch.

## Images

Image upload (`/api/upload`) **requires a Blob token that is not yet wired**, so
it currently returns 503. Until the user sets it up, use **external image URLs**
in Markdown:

```markdown
![Alt text](https://example.com/diagram.png)
```

If the user asks to upload an image, tell them the upload endpoint isn't
configured yet and offer the external-URL alternative.

## Math (KaTeX)

| Syntax | Use | Example |
|--------|-----|---------|
| `$...$` | inline math | `$a^2 + b^2 = c^2$` |
| `$$...$$` | display math (centered) | `$$\int_0^1 x^2\,dx = \frac{1}{3}$$` |

KaTeX commands: `\frac{}{}`, `\sqrt{}`, `\sum`, `\int`, `\lim`, `\mathbb{R}`,
Greek (`\alpha`, `\beta`, `\theta`), superscript `^`, subscript `_`.

Malformed LaTeX renders an inline red error, never a 500 — so a stray `$` won't
break the article.

## Custom blocks

````markdown
:::pullquote
A quadratic is just a number times a square, shifted.
:::

:::figure
![triangle](https://example.com/tri.png)
:::figcaption
Figure 1: The right triangle.
:::
````

Only `pullquote`, `figure`, `figcaption` are supported. Unknown directive names
are ignored.

## Publishing workflow

1. **Draft the article** in Markdown with math/TikZ/blocks.
2. **Check TikZ escaping** — single backslashes in source, no `\documentclass`.
3. **Create as draft** (`status: "draft"`) via the helper or a direct API call.
4. **Preview** the draft at `https://maths-blog.vercel.app/admin` (login
   `troisrivers` + the admin password). Drafts aren't public.
5. **Publish** via `PUT` with `status: "published"`, or create with
   `status: "published"` directly if confident.
6. **Verify** the public URL `https://maths-blog.vercel.app/posts/{slug}`.

If a diagram fails to compile, the post still saves — the diagram shows a
fallback. Fix the TikZ source and re-save to retry.

## Helper script

`scripts/publish.mjs` wraps create/update with correct escaping. Run it from any
directory:

```
node ~/.agents/skills/maths-blog-publisher/scripts/publish.mjs --help
node ~/.agents/skills/maths-blog-publisher/scripts/publish.mjs list
node ~/.agents/skills/maths-blog-publisher/scripts/publish.mjs create --title "..." --file article.md --publish
```

Prefer the script for any create/update — it reads the body from a file so
backslashes survive intact.

## Limitations

- TikZ libraries: only the 5 listed above.
- No `pgfplots`, `tikz-cd`, `circuitikz` unless added to the service.
- Image upload: not yet configured (use external URLs).
- One admin account (`troisrivers`); the agent API key grants full CRUD.
- Rate limit: 60 req/min (enforced when Upstash is wired; otherwise unlimited).
