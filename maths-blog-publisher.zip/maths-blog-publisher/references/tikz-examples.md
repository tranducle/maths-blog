# TikZ examples (verified to render on the blog)

All five diagrams below compile cleanly through the render service (xelatex →
SVG). Copy the code block as the **body** of a ` ```tikz ` fence in your article.
Backslashes are single in this source — when you save via the helper script
(which reads from a file), they survive intact; if you send JSON manually, the
encoder doubles them automatically.

## 1. Right triangle with labels and right-angle mark

````markdown
```tikz
\begin{tikzpicture}[thick]
  \fill[blue!15] (0,0) -- (4,0) -- (0,3) -- cycle;
  \draw (0,0) -- (4,0) -- (0,3) -- cycle;
  \draw (0.35,0) -- (0.35,0.35) -- (0,0.35);
  \node[below left]  at (0,0) {$A$};
  \node[below right] at (4,0) {$B$};
  \node[above left]  at (0,3) {$C$};
  \node[below] at (2,0)    {$b$};
  \node[left]  at (0,1.5)  {$a$};
  \node[above right] at (2,1.5) {$c$};
\end{tikzpicture}
```
````

## 2. Unit circle with an angle θ

````markdown
```tikz
\begin{tikzpicture}[thick, scale=1.8]
  \fill[blue!10] (0,0) -- (0.866,0.5) arc (30:0:1) -- cycle;
  \draw (0,0) circle (1);
  \draw[->] (0,0) -- (1,0);
  \draw[->] (0,0) -- (0.866,0.5);
  \draw (0.2,0) arc (0:30:0.2);
  \node at (0.4,0.08) {$\theta$};
  \node[below] at (0.5,0) {$1$};
\end{tikzpicture}
```
````

## 3. Graph of y = x² (with axes and ticks)

````markdown
```tikz
\begin{tikzpicture}[thick, scale=0.8]
  \draw[->] (-2.7,0) -- (2.7,0) node[right] {$x$};
  \draw[->] (0,-0.5) -- (0,4.3) node[above] {$y$};
  \foreach \x in {-2,-1,1,2} \draw (\x,0.1) -- (\x,-0.1) node[below] {$\x$};
  \foreach \y in {1,2,3} \draw (0.1,\y) -- (-0.1,\y) node[left] {$\y$};
  \draw[blue, domain=-2:2, smooth, samples=40] plot (\x, {\x*\x});
  \node[blue] at (1.7,3.7) {$y = x^2$};
\end{tikzpicture}
```
````

## 4. Flowchart (Vietnamese labels OK — xelatex handles Unicode)

````markdown
```tikz
\begin{tikzpicture}[
  thick,
  box/.style={draw, rounded corners, minimum width=2.5cm, minimum height=1cm, fill=blue!8},
  arr/.style={-Stealth, thick}
]
  \node[box] (input) {Đầu vào $x$};
  \node[box, right=1.5cm of input] (process) {Tính $f(x)$};
  \node[box, right=1.5cm of process] (output) {Kết quả $y$};
  \draw[arr] (input) -- (process);
  \draw[arr] (process) -- (output);
\end{tikzpicture}
```
````

## 5. Triangle with a marked angle (using calc for label placement)

````markdown
```tikz
\begin{tikzpicture}[thick]
  \coordinate (A) at (0,0);
  \coordinate (B) at (5,0);
  \coordinate (C) at (2,3.5);
  \draw (A) -- (B) -- (C) -- cycle;
  \node[below left]  at (A) {$A$};
  \node[below right] at (B) {$B$};
  \node[above]       at (C) {$C$};
  \draw (0.6,0) arc (0:60:0.6);
  \node at (0.9,0.25) {$\alpha$};
  \draw ($(A)!0.5!(B)$) node[below] {cạnh đáy};
\end{tikzpicture}
```
````

---

## Cheat sheet (common commands)

| Command | Effect |
|---------|--------|
| `\draw (0,0) -- (3,2);` | line |
| `\fill[red!30] (0,0) -- (1,0) -- (1,1) -- cycle;` | filled region |
| `\filldraw[fill=blue!20,draw=black] (0,0) circle (1);` | filled+outlined circle |
| `\node at (2,0) {text};` | label |
| `\node[below, red] at (2,0) {...};` | styled label |
| `\draw (0,0) circle (2);` | circle |
| `\draw (0,0) rectangle (3,2);` | rectangle |
| `\draw[->] (0,0) -- (3,0);` | arrow |
| `\draw[-Stealth] (0,0) -- (3,0);` | nice arrow (needs arrows.meta, included) |
| `\draw (1,0) arc (0:90:1);` | arc |
| `\draw[dashed] ...;` | dashed line |

**Options** (in `[...]`): `thick`, `very thick`, `blue`, `red!30`, `scale=2`, `dashed`, `dotted`, `fill=blue!20`.

**Math labels:** `$A$`, `$\theta$`, `$\alpha$`, `$x^2$`, `$\frac{a}{b}$`.

**Hard rules:**
- Every command ends with `;`
- Only send the `\begin{tikzpicture}...\end{tikzpicture}` body (no documentclass/usepackage)
- Single backslashes in source (`\draw`, not `\\draw`)
