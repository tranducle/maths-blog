#!/usr/bin/env node
// Maths Blog Publisher — CLI helper for the Agent API.
// Reads the body from a FILE so backslashes in TikZ survive intact (the #1 bug).
//
//   node publish.mjs --help
//   node publish.mjs list [--status all] [--q needle] [--tag x] [--limit 20]
//   node publish.mjs create --title "..." [--file article.md] [--draft|--publish] [--slug s] [--category C] [--tags a,b] [--deck "..."]
//   node publish.mjs update <id> --file article.md [--title "..."] [--publish]
//   node publish.mjs delete <id>
//   node publish.mjs get <id-or-slug>
import { readFileSync, existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

const SKILL_DIR = join(homedir(), ".agents", "skills", "maths-blog-publisher");
const BASE = process.env.MATHS_BLOG_URL || "https://maths-blog.vercel.app";

function apiKey() {
  if (process.env.MATHS_BLOG_API_KEY) return process.env.MATHS_BLOG_API_KEY.trim();
  const f = join(SKILL_DIR, "scripts", ".api-key");
  if (existsSync(f)) return readFileSync(f, "utf8").trim();
  console.error("No API key. Set MATHS_BLOG_API_KEY or create scripts/.api-key");
  process.exit(1);
}

async function api(method, path, body) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${apiKey()}`,
      ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch {}
  return { status: res.status, json, text };
}

function usage() {
  console.log(`maths-blog publisher

  list [--status all|published|draft] [--q needle] [--tag x] [--limit 20]
      List posts. Default status=published.
  create --title "..." [--file article.md] [--draft|--publish]
         [--slug s] [--category C] [--tags a,b] [--deck "..."] [--author N]
      Create a post. Reads bodyMarkdown from --file (so backslashes survive).
      Defaults to draft; use --publish to publish immediately.
  update <id> --file article.md [--title "..."] [--publish] [--draft]
      Update a post's body (re-renders TikZ). Other fields optional.
  delete <id>
      Delete a post.
  get <id-or-slug>
      Fetch a post by id (uses list + filter for slug).

Env:
  MATHS_BLOG_URL       override base URL (default ${BASE})
  MATHS_BLOG_API_KEY   override API key`);
}

function parseFlags(argv) {
  const flags = {};
  const positional = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const key = a.slice(2);
      if (["draft", "publish"].includes(key)) { flags[key] = true; continue; }
      const next = argv[i + 1];
      if (next === undefined || next.startsWith("--")) { flags[key] = true; continue; }
      flags[key] = next; i++;
    } else positional.push(a);
  }
  return { flags, positional };
}

const [, , cmd, ...rest] = process.argv;
const { flags, positional } = parseFlags(rest);

switch (cmd) {
  case "list": {
    const p = new URLSearchParams();
    if (flags.status) p.set("status", flags.status);
    if (flags.q) p.set("q", flags.q);
    if (flags.tag) p.set("tag", flags.tag);
    if (flags.limit) p.set("limit", flags.limit);
    const r = await api("GET", `/api/agent/posts?${p}`);
    if (r.status !== 200) { console.error(`list failed: ${r.status}`, r.text); process.exit(1); }
    const posts = r.json.posts || [];
    console.log(`${posts.length} post(s):`);
    for (const p of posts) {
      console.log(`  [${p.status}] ${p.id}  ${p.slug}`);
      console.log(`        ${p.title}`);
    }
    break;
  }
  case "create": {
    if (!flags.title) { console.error("--title is required"); process.exit(1); }
    let bodyMarkdown = "";
    if (flags.file) {
      if (!existsSync(flags.file)) { console.error(`file not found: ${flags.file}`); process.exit(1); }
      bodyMarkdown = readFileSync(flags.file, "utf8");
    }
    const body = {
      title: flags.title,
      bodyMarkdown,
      status: flags.publish ? "published" : "draft",
    };
    if (flags.slug) body.slug = flags.slug;
    if (flags.category) body.category = flags.category;
    if (flags.tags) body.tags = String(flags.tags).split(",").map(t => t.trim()).filter(Boolean);
    if (flags.deck) body.deck = flags.deck;
    if (flags.author) body.author = flags.author;
    const r = await api("POST", "/api/agent/posts", body);
    if (r.status !== 201) { console.error(`create failed: ${r.status}`, r.text); process.exit(1); }
    const p = r.json.post;
    console.log(`created [${p.status}]: ${p.id}`);
    console.log(`  url: ${BASE}/posts/${p.slug}`);
    console.log(`  admin: ${BASE}/admin/editor/${p.id}`);
    break;
  }
  case "update": {
    const id = positional[0];
    if (!id) { console.error("id required"); process.exit(1); }
    const body = {};
    if (flags.file) {
      if (!existsSync(flags.file)) { console.error(`file not found: ${flags.file}`); process.exit(1); }
      body.bodyMarkdown = readFileSync(flags.file, "utf8");
    }
    if (flags.title) body.title = flags.title;
    if (flags.publish) body.status = "published";
    if (flags.draft) body.status = "draft";
    if (flags.slug) body.slug = flags.slug;
    const r = await api("PUT", `/api/agent/posts/${id}`, body);
    if (r.status !== 200) { console.error(`update failed: ${r.status}`, r.text); process.exit(1); }
    const p = r.json.post;
    console.log(`updated [${p.status}]: ${p.id}`);
    console.log(`  url: ${BASE}/posts/${p.slug}`);
    break;
  }
  case "delete": {
    const id = positional[0];
    if (!id) { console.error("id required"); process.exit(1); }
    const r = await api("DELETE", `/api/agent/posts/${id}`);
    if (r.status !== 200) { console.error(`delete failed: ${r.status}`, r.text); process.exit(1); }
    console.log(`deleted: ${id}`);
    break;
  }
  case "get": {
    const q = positional[0];
    if (!q) { console.error("id or slug required"); process.exit(1); }
    // Try as id via update-less GET isn't supported; use list + filter.
    const r = await api("GET", `/api/agent/posts?status=all&limit=100`);
    const p = (r.json.posts || []).find(x => x.id === q || x.slug === q);
    if (!p) { console.error(`not found: ${q}`); process.exit(1); }
    console.log(JSON.stringify(p, null, 2));
    break;
  }
  default:
    usage();
    process.exit(cmd ? 1 : 0);
}
